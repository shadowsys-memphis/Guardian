import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf-8');

// Fix tabs
content = content.replace(/shadow-\[0_4px_0_0_white\]/g, 'shadow-[0_4px_0_0_#121b29]');
content = content.replace(/text-indigo-700/g, 'text-[#8da4c4]');
content = content.replace(/text-indigo-600/g, 'text-[#8da4c4]');
content = content.replace(/hover:text-indigo-600/g, 'hover:text-[#bba35a]');
content = content.replace(/bg-indigo-600/g, 'bg-[#364966]');
content = content.replace(/hover:bg-indigo-700/g, 'hover:bg-[#233550]');
content = content.replace(/bg-indigo-50\/30/g, 'bg-[#1a273b]/50');
content = content.replace(/bg-indigo-50/g, 'bg-[#1a273b]');
content = content.replace(/border-indigo-200/g, 'border-[#364966]');
content = content.replace(/border-indigo-100/g, 'border-[#364966]');
content = content.replace(/text-indigo-800/g, 'text-[#8da4c4]');
content = content.replace(/text-indigo-500/g, 'text-[#8da4c4]');
content = content.replace(/text-emerald-600/g, 'text-[#bba35a]');
content = content.replace(/text-emerald-700/g, 'text-[#bba35a]');
content = content.replace(/hover:text-emerald-600/g, 'hover:text-[#d4bc6d]');
content = content.replace(/bg-emerald-600/g, 'bg-[#bba35a]');
content = content.replace(/hover:bg-emerald-700/g, 'hover:bg-[#d4bc6d]');
content = content.replace(/border-emerald-100/g, 'border-[#364966]');
content = content.replace(/border-emerald-400/g, 'border-[#bba35a]');
content = content.replace(/focus:border-emerald-400/g, 'focus:border-[#bba35a]');
content = content.replace(/focus:border-indigo-400/g, 'focus:border-[#bba35a]');
content = content.replace(/text-[#383531]/g, 'text-[#e5e7eb]');
content = content.replace(/bg-\[#fffefe\]/g, 'bg-[#080d14]'); // ensure all whites are gone

content = content.replace(/className="max-w-5xl mx-auto"/g, 'className="max-w-[1400px] mx-auto"'); // make it wider and more commanding
content = content.replace(/rounded-xl|rounded-2xl/g, 'rounded-none'); // brutalist hard edges
content = content.replace(/rounded-lg/g, 'rounded-sm');

// Replace "Clinical Dashboard" top wording to sound more military.
content = content.replace(/Pops' Clinical Caregiver Dashboard/g, "Pops' Guardian-OS Console");
content = content.replace(/A zero-touch environment/g, "High-Contrast Tactical Interface");

fs.writeFileSync('src/App.tsx', content);
console.log('Restyling pass 2 done');
