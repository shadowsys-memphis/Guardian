import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf-8');

// Bump font sizes for accessibility.
content = content.replace(/text-xs/g, 'text-sm font-medium');
content = content.replace(/text-\[10px\]/g, 'text-xs font-bold tracking-wider');
content = content.replace(/text-\[11px\]/g, 'text-sm');
content = content.replace(/text-sm/g, 'text-base');
content = content.replace(/text-base/g, 'text-lg');
content = content.replace(/className="text-2xl/g, 'className="text-4xl text-[#bba35a]');
content = content.replace(/font-semibold/g, 'font-bold');

fs.writeFileSync('src/App.tsx', content);
console.log('Restyling pass 3 done');
