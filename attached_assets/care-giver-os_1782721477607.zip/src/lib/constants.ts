import { PatientTask, HistoricalCareLog } from "../types";

export const DEFAULT_TASKS: PatientTask[] = [
  // MORNING (06:00 - 12:00)
  {
    id: "task-m1",
    title: "Warm fluid offer: 4oz lemon ginger water (Hydration goal)",
    period: "morning",
    timeSlot: "07:00 AM (Hourly)",
    isHourlyOrBiHourly: true,
    category: "Food Intake",
    status: "Done",
    completedAt: "2026-06-22T07:05:00.000Z"
  },
  {
    id: "task-m2",
    title: "Body posture alignment rotation & shoulder stretch (Lying-up pose)",
    period: "morning",
    timeSlot: "08:00 AM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Physical Rotation",
    status: "Done",
    completedAt: "2026-06-22T08:02:00.000Z"
  },
  {
    id: "task-m3",
    title: "Daily Blood Pressure & SpO2 Biometric reading (Target: BP < 130/80)",
    period: "morning",
    timeSlot: "08:30 AM",
    isHourlyOrBiHourly: false,
    category: "Biometric Read",
    status: "Done",
    completedAt: "2026-06-22T08:35:00.000Z",
    loggedNote: "119/74 BP, 98% SpO2. Excellent resting cardiorespiratory status."
  },
  {
    id: "task-m4",
    title: "Fluid validation: 4oz electrolyte water",
    period: "morning",
    timeSlot: "09:00 AM (Hourly)",
    isHourlyOrBiHourly: true,
    category: "Food Intake",
    status: "Done",
    completedAt: "2026-06-22T09:01:00.000Z"
  },
  {
    id: "task-m5",
    title: "Administer Routine Morning Meds (Anti-hypertensive & Neuro-nutrients)",
    period: "morning",
    timeSlot: "09:30 AM",
    isHourlyOrBiHourly: false,
    category: "Medication",
    status: "Done",
    medResponse: "stable",
    completedAt: "2026-06-22T09:38:00.000Z",
    loggedNote: "Administered with soft banana spoon. Minimal dry mouth reported."
  },
  {
    id: "task-m6",
    title: "Sore pressure check & position shift (Alternate to right decubitus)",
    period: "morning",
    timeSlot: "10:00 AM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Physical Rotation",
    status: "Todo"
  },
  {
    id: "task-m7",
    title: "Gentle Brain Puzzle & Pattern Sequence checking session",
    period: "morning",
    timeSlot: "11:00 AM",
    isHourlyOrBiHourly: false,
    category: "Cognitive",
    status: "Todo"
  },

  // AFTERNOON (12:00 - 18:00)
  {
    id: "task-a1",
    title: "Pressure relief check: shift posture & limb alignment check",
    period: "afternoon",
    timeSlot: "12:00 PM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Physical Rotation",
    status: "Todo"
  },
  {
    id: "task-a2",
    title: "Check soft diet ingestion compliance (Warm soup nourishment monitoring)",
    period: "afternoon",
    timeSlot: "12:30 PM",
    isHourlyOrBiHourly: false,
    category: "Food Intake",
    status: "Todo"
  },
  {
    id: "task-a3",
    title: "Fluid check: Offer pure berry gelatin/hydration",
    period: "afternoon",
    timeSlot: "14:00 PM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Food Intake",
    status: "Todo"
  },
  {
    id: "task-a4",
    title: "Sore prevention shift: rotate to Left Lateral Recumbent posture",
    period: "afternoon",
    timeSlot: "16:00 PM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Physical Rotation",
    status: "Todo"
  },
  {
    id: "task-a5",
    title: "Cognitive coordination & family board check (Support status ingestion)",
    period: "afternoon",
    timeSlot: "17:00 PM",
    isHourlyOrBiHourly: false,
    category: "Cognitive",
    status: "Todo"
  },

  // NIGHT (18:00 - 06:00)
  {
    id: "task-n1",
    title: "Administer Comfort & Bedtime Meds (Soft digestion routine)",
    period: "night",
    timeSlot: "18:30 PM",
    isHourlyOrBiHourly: false,
    category: "Medication",
    status: "Todo"
  },
  {
    id: "task-n2",
    title: "Check room climate index & check bedding temperature (target: 72°F)",
    period: "night",
    timeSlot: "19:00 PM (Hourly)",
    isHourlyOrBiHourly: true,
    category: "Physical Rotation",
    status: "Todo"
  },
  {
    id: "task-n3",
    title: "Prepare mattress inflation calibration & lower rails safeguard",
    period: "night",
    timeSlot: "20:00 PM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Physical Rotation",
    status: "Todo"
  },
  {
    id: "task-n4",
    title: "Sore pressure check: rotate to standard spine alignment with pillows under ankles",
    period: "night",
    timeSlot: "22:00 PM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Physical Rotation",
    status: "Todo"
  },
  {
    id: "task-n5",
    title: "Verify oxygen flow & resting respiration rate (Target: 14-18 breathes/min)",
    period: "night",
    timeSlot: "00:00 AM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Biometric Read",
    status: "Todo"
  },
  {
    id: "task-n6",
    title: "Deep sleep position shift: rotate shoulders lightly to alleviate neck strain",
    period: "night",
    timeSlot: "02:00 AM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Physical Rotation",
    status: "Todo"
  },
  {
    id: "task-n7",
    title: "Quiet resting hydration: inspect moisture level in oral cavity",
    period: "night",
    timeSlot: "04:00 AM (Bi-hourly)",
    isHourlyOrBiHourly: true,
    category: "Food Intake",
    status: "Todo"
  }
];

export const PRELOADED_HISTORICAL_LOGS: HistoricalCareLog[] = [
  {
    id: "log-w1",
    date: "Week 1 (June 1 - June 7)",
    rateOfWantsResponded: 96,
    medAdherence: 95,
    soreRotationComplete: 90,
    generalNotes: "Initial integration of the Zero-Touch bedside tablet. Pops responded extremely well to click triggers, totally avoiding loud vocal yelling. Compliance is stable.",
    efficacyScore: 9
  },
  {
    id: "log-w2",
    date: "Week 2 (June 8 - June 14)",
    rateOfWantsResponded: 100,
    medAdherence: 100,
    soreRotationComplete: 94,
    generalNotes: "Medication response logs show moderate afternoon sleepiness following hypertensive dosage. Shifted cognitive sessions to 11 AM as a result, which greatly improved scores.",
    efficacyScore: 10
  },
  {
    id: "log-w3",
    date: "Week 3 (June 15 - June 21)",
    rateOfWantsResponded: 92,
    medAdherence: 92,
    soreRotationComplete: 88,
    generalNotes: "Minor skin irritation detected on lower flank; increased physical rotation chores from bi-hourly to hourly during transition. Irritation cleared smoothly.",
    efficacyScore: 8
  }
];
