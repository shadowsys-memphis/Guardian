/**
 * Secure cryptographic helper for End-to-End Encryption (E2EE) in Br[AI]n.
 * Uses PBKDF2 for key derivation and AES-GCM for standard modern browser encryption.
 */

// Helper to convert ArrayBuffer <-> Base64
function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

/**
 * Derives a CryptoKey using PBKDF2 from a passphrase and a salt.
 */
async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(passphrase),
    { name: "PBKDF2" },
    false,
    ["deriveKey", "deriveBits"]
  );

  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt,
      iterations: 100000,
      hash: "SHA-256",
    },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

/**
 * Encrypts data using a user-specified passphrase.
 * Returns a self-contained Base64 package: "salt.iv.ciphertext"
 */
export async function encryptData(data: any, passphrase: string): Promise<string> {
  if (!passphrase) throw new Error("Passphrase required for encryption");
  const enc = new TextEncoder();
  const rawData = enc.encode(JSON.stringify(data));

  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));

  const key = await deriveKey(passphrase, salt);

  const ciphertextBuffer = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv },
    key,
    rawData
  );

  const saltB64 = arrayBufferToBase64(salt);
  const ivB64 = arrayBufferToBase64(iv);
  const ciphertextB64 = arrayBufferToBase64(ciphertextBuffer);

  return `${saltB64}.${ivB64}.${ciphertextB64}`;
}

/**
 * Decrypts a base64 encrypted packet back to its original JSON.
 */
export async function decryptData(encryptedStr: string, passphrase: string): Promise<any> {
  if (!passphrase) throw new Error("Passphrase required for decryption");
  const parts = encryptedStr.split(".");
  if (parts.length !== 3) {
    throw new Error("Invalid encrypted format");
  }

  const [saltB64, ivB64, ciphertextB64] = parts;

  const salt = new Uint8Array(base64ToArrayBuffer(saltB64));
  const iv = new Uint8Array(base64ToArrayBuffer(ivB64));
  const ciphertext = base64ToArrayBuffer(ciphertextB64);

  const key = await deriveKey(passphrase, salt);

  try {
    const decryptedBuffer = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv },
      key,
      ciphertext
    );

    const dec = new TextDecoder();
    return JSON.parse(dec.decode(decryptedBuffer));
  } catch (err) {
    throw new Error("Decryption failed. Incorrect passphrase/key.");
  }
}
