import { useState, useEffect, useRef, FormEvent } from "react";
import {
  PhoneCall,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Play,
  RotateCcw,
  Sparkles,
  Calendar,
  Send,
  Loader2,
  Zap
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface TwilioAssistantProps {
  context: any; // household state object
  onTriggerActions: (actions: any[]) => void;
}

export default function TwilioAssistant({ context, onTriggerActions }: TwilioAssistantProps) {
  const [callState, setCallState] = useState<"idle" | "calling" | "connected" | "ended">("idle");
  const [userInput, setUserInput] = useState("");
  const [messages, setMessages] = useState<{ role: "user" | "assistant"; text: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [speakerOn, setSpeakerOn] = useState(true);
  const [triggeredAlerts, setTriggeredAlerts] = useState<string[]>([]);
  
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Play synthetic tone when clicking buttons
  const playTone = (freq: number, duration = 100) => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration / 1000);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration / 1000);
    } catch (e) {
      // Ignored
    }
  };

  const handleDial = () => {
    playTone(350, 400); // Dial tone combination
    setTimeout(() => playTone(440, 400), 100);
    setCallState("calling");
    
    // Simulate connection delay
    setTimeout(() => {
      setCallState("connected");
      setMessages([
        {
          role: "assistant",
          text: "Br[AI]n Support Core connected. Hello Emily. I am monitoring Mom's recovery cycle and Pops' cognitive schedule today. How can I assist you with scheduling or thermostat setups?"
        }
      ]);
      playTone(880, 250);
    }, 2000);
  };

  const handleEndCall = () => {
    playTone(220, 500);
    setCallState("ended");
    setTimeout(() => {
      setCallState("idle");
      setMessages([]);
      setTriggeredAlerts([]);
    }, 1500);
  };

  // Play base64 audio response from Gemini TTS
  const playBinaryAudio = async (base64Str: string) => {
    if (!speakerOn) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;

      const binary = atob(base64Str);
      const len = binary.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binary.charCodeAt(i);
      }

      const audioBuffer = await ctx.decodeAudioData(bytes.buffer);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.start();
    } catch (err) {
      console.error("Failed to decode and play audio stream:", err);
    }
  };

  const handleSendMessage = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    if (!userInput.trim() || loading) return;

    const userText = userInput.trim();
    setUserInput("");
    setMessages((prev) => [...prev, { role: "user", text: userText }]);
    setLoading(true);

    try {
      const response = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userText,
          history: messages,
          context: context,
          speak: speakerOn
        })
      });

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      let aiText = data.text;
      
      // Look for JSON Action triggers inside text, format: ---ACTION--- ... ---END_ACTION---
      const actionMatch = aiText.match(/---ACTION---([\s\S]*?)---END_ACTION---/);
      if (actionMatch) {
        try {
          const parsedActions = JSON.parse(actionMatch[1].trim());
          onTriggerActions(parsedActions);

          // Add visual logs
          const actionLabels = parsedActions.map((a: any) => {
            if (a.type === "ADD_EVENT") return `Authorized Calendar Appointment: ${a.payload.title}`;
            if (a.type === "TOGGLE_SMART_DEVICE") return `Nest Device Overridden: ${a.payload.id} ➔ ${a.payload.status}`;
            if (a.type === "ADD_TASK") return `Assigned Duty: ${a.payload.title}`;
            return "Command Triggered";
          });
          setTriggeredAlerts((prev) => [...prev, ...actionLabels]);
        } catch (jsonErr) {
          console.error("Action parsing failed:", jsonErr);
        }
        // Clean conversational text for final view
        aiText = aiText.replace(/---ACTION---[\s\S]*---END_ACTION---/g, "").trim();
      }

      setMessages((prev) => [...prev, { role: "assistant", text: aiText }]);

      // If speak is enabled and audio is retrieved, decode and play
      if (speakerOn && data.audio) {
        await playBinaryAudio(data.audio);
      }
    } catch (err: any) {
      setMessages((prev) => [
        { role: "assistant", text: `I encountered an issue syncing with the core link: ${err.message}` }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const DEMO_PRESETS = [
    "Schedule Mom's physical therapy for Wednesday at 10 AM",
    "Turn up living room climate to 75°F",
    "Add critical medication check for Pops at 6 PM"
  ];

  return (
    <div className="glass-panel rounded-2xl p-5 relative overflow-hidden" id="twilio-widget-container">
      {/* Dialer Header */}
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-300 rotate-6" />
            Zero-Touch Dialer Link
          </h3>
          <p className="text-[10px] text-slate-500 font-mono mt-0.5">Automates calendars & nest overrides using voice</p>
        </div>

        <button
          onClick={() => setSpeakerOn(!speakerOn)}
          className={`p-1.5 rounded-lg border transition ${
            speakerOn
              ? "bg-emerald-950/40 border-emerald-500/25 text-emerald-300"
              : "bg-white/5 border border-white/10 text-slate-500"
          }`}
          title={speakerOn ? "Mute Synthetic Spoken Call" : "Unmute Synthetic Speech"}
          id="toggle-voice-speaker"
        >
          {speakerOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>
      </div>

      {callState === "idle" && (
        <div className="text-center py-6 bg-black/20 border border-white/5 rounded-xl space-y-4">
          <p className="text-xs text-slate-400 font-sans max-w-xs mx-auto">
            Simulate an interactive phone hotline. Connects to Br[AI]n AI Agent to speak appointments, duties, and home overrides.
          </p>

          <button
            onClick={handleDial}
            className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 hover:scale-[1.01] active:scale-[0.98] text-white font-bold rounded-full font-mono text-xs uppercase tracking-wider flex items-center gap-2 mx-auto transition shadow-lg shadow-emerald-500/10"
            id="simulate-call-btn"
          >
            <PhoneCall className="w-4 h-4 text-white fill-current" />
            Connect Twilio Line
          </button>
        </div>
      )}

      {callState === "calling" && (
        <div className="text-center py-8 bg-black/30 border border-white/5 rounded-xl space-y-4">
          <div className="flex justify-center gap-1.5 items-end h-6">
            {[1, 2, 3, 4, 5].map((i) => (
              <span
                key={i}
                className="w-1 bg-emerald-400 rounded-full animate-bounce"
                style={{
                  height: `${Math.random() * 24 + 4}px`,
                  animationDelay: `${i * 150}ms`
                }}
              />
            ))}
          </div>
          <div>
            <p className="text-xs text-emerald-300 font-mono uppercase tracking-widest animate-pulse">
              Bridging Secure Twilio Tunnel...
            </p>
            <p className="text-[10px] text-slate-500 font-mono mt-0.5">TLS 1.3 Encryption Active</p>
          </div>
          <button
            onClick={handleEndCall}
            className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-full font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 mx-auto"
          >
            <PhoneOff className="w-3.5 h-3.5" />
            Hang Up
          </button>
        </div>
      )}

      {callState === "connected" && (
        <div className="space-y-4" id="twilio-connected-sub-screen">
          {/* Animated Waveform */}
          <div className="flex items-center justify-between p-3 bg-black/20 border border-white/5 rounded-xl">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="text-xs font-mono font-bold text-emerald-300">CALL STATUS: ACTIVE</span>
            </div>
            <div className="flex gap-1 items-center">
              {[1, 2, 3, 4].map((i) => (
                <div
                   key={i}
                   className="w-0.5 bg-emerald-400 rounded-full animate-pulse"
                   style={{
                     height: `${Math.random() * 12 + 4}px`,
                     animationDelay: `${i * 100}ms`
                   }}
                />
              ))}
            </div>
          </div>

          {/* Dialog Flow */}
          <div className="h-44 overflow-y-auto border border-white/5 bg-black/20 p-3 rounded-xl space-y-3 font-sans scrollbar-thin">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex flex-col max-w-[85%] ${
                  m.role === "user" ? "ml-auto items-end" : "mr-auto items-start"
                }`}
              >
                <div className={`p-2.5 rounded-xl text-xs ${
                  m.role === "user"
                    ? "bg-emerald-500/10 border border-emerald-500/25 text-emerald-50 rounded-tr-none"
                    : "bg-white/10 border border-white/5 text-slate-200 rounded-tl-none"
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-slate-500 text-xs font-mono py-1">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-300" />
                <span>AI Agent interpreting speech...</span>
              </div>
            )}
          </div>

          {/* Triggered Actions Stream */}
          {triggeredAlerts.length > 0 && (
            <div className="p-3.5 bg-black/20 border border-white/5 rounded-xl space-y-1" id="triggered-actions-stream">
              <p className="text-[10px] font-mono uppercase font-bold text-emerald-300 flex items-center gap-1">
                <Zap className="w-3 h-3 text-emerald-300" />
                Dispatched Decrypted State Actions (Local)
              </p>
              <div className="space-y-1">
                {triggeredAlerts.map((alert, i) => (
                  <p key={i} className="text-[10px] font-mono text-slate-400 flex items-center gap-1 truncate">
                    ➔ {alert}
                  </p>
                ))}
              </div>
            </div>
          )}

          {/* Presets and entry */}
          <div className="space-y-2">
            <p className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">Suggested Speech Triggers</p>
            <div className="flex flex-wrap gap-1.5">
              {DEMO_PRESETS.map((preset, i) => (
                <button
                  key={i}
                  onClick={() => setUserInput(preset)}
                  className="text-[9px] font-mono text-slate-400 bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 p-1.5 py-1 rounded"
                >
                  "{preset}"
                </button>
              ))}
            </div>

            <form onSubmit={handleSendMessage} className="flex gap-2 relative mt-2">
              <input
                type="text"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder="What is your request?"
                className="w-full bg-black/30 border border-white/10 rounded-xl p-2.5 text-xs text-slate-200 outline-none focus:border-emerald-300 transition"
              />
              <button
                type="submit"
                className="p-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition"
              >
                <Send className="w-4 h-4 text-white" />
              </button>
            </form>
          </div>

          {/* End Call controls */}
          <button
            onClick={handleEndCall}
            className="w-full py-2 bg-rose-500/10 border border-rose-500/20 text-rose-300 font-bold font-mono rounded-xl hover:bg-rose-500/20 transition text-xs flex items-center justify-center gap-1.5"
            id="hangup-action-btn"
          >
            <PhoneOff className="w-3.5 h-3.5 text-rose-300" />
            Terminate Link Tunnel
          </button>
        </div>
      )}
    </div>
  );
}
