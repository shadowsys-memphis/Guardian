import React, { useState } from "react";
import { Shield, Eye, EyeOff, Lock, Unlock, Key, HardDrive } from "lucide-react";
import { motion } from "motion/react";

interface EncryptionUnlockProps {
  onUnlock: (passphrase: string) => void;
  savedCipherText: string | null;
}

export default function EncryptionUnlock({ onUnlock, savedCipherText }: EncryptionUnlockProps) {
  const [passphrase, setPassphrase] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [showCipherText, setShowCipherText] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passphrase.trim()) {
      onUnlock(passphrase.trim());
    } else {
      alert("Please enter a secure passphrase to initialize.");
    }
  };

  const handleSkip = () => {
    onUnlock("demo-secure-cleartext-fallback");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-4 relative overflow-hidden" id="unlock-container" style={{ backgroundImage: "radial-gradient(circle at 0% 0%, #0d1e16 0%, #060b09 100%), radial-gradient(circle at 100% 100%, #1c0e0e 0%, transparent 50%)" }}>
      {/* Decorative Grid Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 pointer-events-none"></div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative max-w-md w-full glass-panel-heavy rounded-3xl p-6 md:p-8 shadow-2xl z-10"
        id="unlock-card"
      >
        <div className="flex flex-col items-center justify-center text-center space-y-4 mb-6">
          <div className="p-4 bg-emerald-500/10 rounded-full border border-emerald-500/20 relative">
            <Shield className="w-10 h-10 text-emerald-300 animate-pulse" />
            <span className="absolute -top-1 -right-1 px-2 py-0.5 text-[9px] font-mono font-bold bg-emerald-500 text-slate-950 rounded-full uppercase tracking-wider shadow-md">
              SECURE
            </span>
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-white font-sans">
              Family <span className="text-emerald-300 font-normal">Shared Space</span>
            </h1>
            <p className="text-[10px] text-emerald-300/80 uppercase tracking-[0.2em] font-semibold font-mono mt-1">
              Keeping our family plans safe & private
            </p>
          </div>
        </div>

        <p className="text-sm text-slate-300 leading-relaxed text-center mb-6">
          All our family messages, schedules, and loving plans are kept private on this computer. They can never be seen by anyone else.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-mono font-bold text-emerald-300 uppercase tracking-widest block">
              Enter Family Room Passphrase
            </label>
            <div className="relative">
              <input
                type={showPass ? "text" : "password"}
                value={passphrase}
                onChange={(e) => setPassphrase(e.target.value)}
                placeholder="Type your passphrase to enter..."
                className="w-full bg-black/40 border border-white/10 focus:border-emerald-300 focus:ring-1 focus:ring-emerald-300 rounded-xl px-4 py-3 text-slate-200 outline-none transition font-sans placeholder-slate-600 pl-10"
                id="passphrase-input"
              />
              <Key className="w-4 h-4 text-slate-500 absolute left-3.5 top-4" />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3.5 top-3.5 text-slate-500 hover:text-slate-300 transition"
              >
                {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-bold py-3.5 px-6 rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10 font-mono text-sm uppercase tracking-wider"
            id="decryption-submit"
          >
            <Unlock className="w-4 h-4 text-white" />
            Open Family Shared Space
          </button>
        </form>

        <div className="mt-4 flex justify-between items-center text-xs">
          <button
            onClick={handleSkip}
            className="text-slate-400 hover:text-emerald-300 transition underline font-mono"
          >
            Use Demo Room
          </button>
          
          {savedCipherText ? (
            <button
              onClick={() => setShowCipherText(!showCipherText)}
              className="text-slate-400 hover:text-emerald-300 transition flex items-center gap-1 font-mono"
            >
              <HardDrive className="w-3.5 h-3.5" />
              {showCipherText ? "Hide Protected Day Data" : "Show Protected Day Data"}
            </button>
          ) : (
            <span className="text-slate-500 italic font-mono text-[10px]">Fresh storage database</span>
          )}
        </div>

        {showCipherText && savedCipherText && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="mt-6 p-3 bg-black/50 border border-white/10 rounded-xl"
          >
            <span className="text-[10px] font-mono text-emerald-300 uppercase block mb-1">
              Protected Local Care State
            </span>
            <div className="text-[10px] font-mono text-slate-400 max-h-24 overflow-y-auto break-all bg-black/40 border border-white/5 p-2 rounded">
              {savedCipherText}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
