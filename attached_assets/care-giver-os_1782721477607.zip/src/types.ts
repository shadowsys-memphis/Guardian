export interface PatientTask {
  id: string;
  title: string;
  period: "morning" | "afternoon" | "night";
  timeSlot: string; // e.g., "08:00 AM"
  isHourlyOrBiHourly: boolean;
  category: "Medication" | "Food Intake" | "Physical Rotation" | "Cognitive" | "Biometric Read";
  status: "Todo" | "Done";
  medResponse?: "stable" | "drowsy" | "fatigued" | "agitated"; // responses to track
  completedAt?: string; // stamp
  loggedNote?: string;
}

export interface HistoricalCareLog {
  id: string;
  date: string;
  rateOfWantsResponded: number; // percentage
  medAdherence: number; // percentage
  soreRotationComplete: number; // percentage
  generalNotes: string;
  efficacyScore: number; // 0-10 index
}

export interface VoiceScript {
  id: string;
  triggerKey: string;
  tone: "calm" | "urgent" | "cheerful" | "strict";
  text: string;
  patchNotes: string;
}

export interface ZeroTouchWant {
  id: string;
  item: string;
  fulfilled: boolean;
  timeRequest: string;
}

export interface SmartHomeDevice {
  id: string;
  name: string;
  type: string;
  status: "on" | "off" | "error";
  batteryLevel?: number;
}

export interface SecureNetworkState {
  patientName: string;
  patientRoom: string;
  targetMedsResponse: string;
  wants: ZeroTouchWant[];
  tasks: PatientTask[];
  devices: SmartHomeDevice[];
  historicalLogs: HistoricalCareLog[];
  initialized: boolean;
}
