import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf-8');

// Replace military colors with modern minimalist elegant zinc theme
content = content.replace(/bg-\[#080d14\]/g, 'bg-zinc-950/50');
content = content.replace(/bg-\[#121b29\]/g, 'bg-zinc-900/80');
content = content.replace(/bg-\[#1a273b\]/g, 'bg-zinc-800');
content = content.replace(/bg-\[#233550\]/g, 'bg-zinc-700');
content = content.replace(/bg-\[#364966\]/g, 'bg-zinc-800');
content = content.replace(/text-\[#bba35a\]/g, 'text-zinc-100');
content = content.replace(/text-\[#8da4c4\]/g, 'text-zinc-400');
content = content.replace(/border-\[#364966\]/g, 'border-zinc-800');
content = content.replace(/border-\[#bba35a\]/g, 'border-zinc-700');
content = content.replace(/hover:bg-\[#233550\]/g, 'hover:bg-zinc-700');
content = content.replace(/hover:bg-\[#d4bc6d\]/g, 'hover:bg-zinc-200');
content = content.replace(/hover:bg-\[#1a273b\]/g, 'hover:bg-zinc-800');
content = content.replace(/hover:text-\[#d4bc6d\]/g, 'hover:text-zinc-300');
content = content.replace(/hover:text-\[#bba35a\]/g, 'hover:text-zinc-200');

// Fix text colors
content = content.replace(/text-gray-200/g, 'text-zinc-200');
content = content.replace(/text-gray-300/g, 'text-zinc-300');
content = content.replace(/text-gray-400/g, 'text-zinc-400');
content = content.replace(/text-gray-100/g, 'text-zinc-100');
content = content.replace(/text-emerald-400/g, 'text-emerald-500');

// Soften borders
content = content.replace(/rounded-none/g, 'rounded-xl');
content = content.replace(/rounded-sm/g, 'rounded-lg');

// Fix Layout and structure - making it feel ultra-premium
content = content.replace(/shadow-\[0_4px_0_0_#bba35a\]/g, 'shadow-sm');
content = content.replace(/uppercase/g, 'tracking-tight'); // remove harsh uppercase
content = content.replace(/tracking-wider/g, 'tracking-normal');
content = content.replace(/tracking-wide/g, 'tracking-normal');

// Wording update - more modern, less aggressive
content = content.replace(/Pops' Guardian-OS Console/g, "Guardian OS");
content = content.replace(/High-Contrast Tactical Interface/g, "Caregiver Command Center");
content = content.replace(/Shopper Engine & Logistics/g, "Logistics & Planning");
content = content.replace(/Ground Truth Engine & Cart List/g, "Active Provisions");
content = content.replace(/AI Grocery Generator/g, "Smart Planning");
content = content.replace(/Approve Cart & Dispatch/g, "Approve & Dispatch");

// Remove hard edges and weird shadows
content = content.replace(/border-t-4/g, 'border-t-0');

fs.writeFileSync('src/App.tsx', content);
console.log('Restyling pass 4 done');
