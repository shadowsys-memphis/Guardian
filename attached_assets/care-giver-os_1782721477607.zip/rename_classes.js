import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf-8');

// Colors & General
content = content.replace(/text-\[#383531\]/g, 'text-gray-100');
content = content.replace(/text-\[#8c8375\]/g, 'text-gray-400');
content = content.replace(/text-\[#736c64\]/g, 'text-gray-400');
content = content.replace(/text-\[#2d2a26\]/g, 'text-[#bba35a]'); // gold text for headers
content = content.replace(/text-\[#5c554e\]/g, 'text-gray-300');
content = content.replace(/text-gray-[789]00/g, 'text-gray-200');
content = content.replace(/text-gray-[45]00/g, 'text-gray-400');
content = content.replace(/text-emerald-[678]00/g, 'text-emerald-400');
content = content.replace(/bg-white(?![A-Za-z])/g, 'bg-[#080d14]');
content = content.replace(/bg-\[#ffffff\]/g, 'bg-[#080d14]');
content = content.replace(/bg-\[#fdfcf9\]|bg-\[#fcfbfa\]|bg-\[#faf9f5\]/g, 'bg-[#121b29]');
content = content.replace(/bg-gray-[51][0]?(?![A-Za-z0-9])/g, 'bg-[#0d1520]');
content = content.replace(/border-\[#e9e5de\]|border-\[#e4dfd5\]|border-\[#f4f1ea\]/g, 'border-[#364966]');
content = content.replace(/border-gray-[12]00/g, 'border-[#364966]');

// Components
content = content.replace(/cozy-card/g, 'command-panel');
content = content.replace(/cozy-input/g, 'command-input');
content = content.replace(/cozy-button-primary/g, 'command-button-primary');
content = content.replace(/cozy-button-secondary/g, 'command-button-secondary');

// Tab adjustments
content = content.replace(/text-\[#bba35a\] shadow-\[0_4px_0_0_#080d14\]/g, 'text-[#bba35a] shadow-[0_4px_0_0_#bba35a]');
content = content.replace(/bg-\[#080d14\] border-\[#364966\] text-gray-200/g, 'bg-[#121b29] border-[#bba35a] text-[#bba35a]');

fs.writeFileSync('src/App.tsx', content);
console.log('Restyling done');
