import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf-8');

// Fix residual colors
content = content.replace(/bg-\[#0d1520\]/g, 'bg-zinc-950');
content = content.replace(/bg-\[#FCFBFA\]/g, 'bg-zinc-900/50');
content = content.replace(/bg-indigo-100/g, 'bg-zinc-800');
content = content.replace(/text-indigo-700/g, 'text-zinc-200');
content = content.replace(/shadow-\[0_4px_0_0_#121b29\]/g, 'shadow-none border-b-0'); // fix the tab borders
content = content.replace(/shadow-\[0_4px_0_0_#080d14\]/g, 'shadow-none border-b-0'); // fix the tab borders
content = content.replace(/shadow-\[0_4px_0_0_#bba35a\]/g, 'shadow-none border-b-0'); // fix the tab borders

// Better tab styling
content = content.replace(/rounded-t-xl border-x border-t/g, 'rounded-xl border border-zinc-800');

// Fix text classes
content = content.replace(/text-zinc-400/g, 'text-zinc-400');
content = content.replace(/text-zinc-200/g, 'text-zinc-100');
content = content.replace(/text-gray-500/g, 'text-zinc-500');

// Fix grid templates and spacing
content = content.replace(/grid-cols\[1fr_300px\]/g, 'grid-cols-[1fr_300px]');

// Fix duplicate tracking
content = content.replace(/tracking-tight tracking-normal/g, 'tracking-normal');
content = content.replace(/font-bold tracking-normal font-bold/g, 'font-bold');

fs.writeFileSync('src/App.tsx', content);
console.log('Restyling pass 5 done');
