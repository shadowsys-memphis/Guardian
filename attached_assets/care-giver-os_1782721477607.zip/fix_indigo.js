import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf-8');

content = content.replace(/text-indigo-[0-9]00/g, 'text-zinc-100');
content = content.replace(/border-indigo-[0-9]00/g, 'border-zinc-700');
content = content.replace(/bg-indigo-[0-9]00/g, 'bg-zinc-800');
content = content.replace(/from-indigo-[0-9]0/g, 'from-zinc-900');

fs.writeFileSync('src/App.tsx', content);
console.log('Fixed indigo');
