/**
 * OpenClaw Skill: get_pops_status
 * 
 * Fetches Pops' current Haldol cycle day and today's schedule 
 * from the Guardian-OS backend via REST API.
 */
async function run() {
  try {
    // 1. Fetch Haldol State
    const haldolRes = await fetch("https://ais-dev-immzmjj6lpnelg5cj4ren5-28709946245.us-east1.run.app/api/haldol");
    const haldolData = await haldolRes.json();
    
    // 2. Fetch Today's Tasks
    const scheduleRes = await fetch("https://ais-dev-immzmjj6lpnelg5cj4ren5-28709946245.us-east1.run.app/api/schedule");
    const scheduleData = await scheduleRes.json();
    
    // 3. Format context for Jessica (OpenClaw)
    let context = `--- POPS' CURRENT STATE ---\n`;
    context += `Haldol Cycle Day: ${haldolData.dayOfCycle} / 14\n`;
    context += `Zombie Phase Active: ${haldolData.isZombiePhase ? 'YES (Days 1-5, keep interactions short & calm)' : 'NO'}\n`;
    context += `Next Injection: ${new Date(haldolData.nextInjectionDate).toLocaleDateString()}\n\n`;
    
    context += `--- TODAY'S TASKS ---\n`;
    const pending = scheduleData.filter(t => t.status !== "Done");
    const completed = scheduleData.filter(t => t.status === "Done");
    
    context += `Completed (${completed.length}):\n`;
    completed.forEach(t => {
      context += `- [DONE] ${t.time}: ${t.title}\n`;
    });
    
    context += `\nPending (${pending.length}):\n`;
    pending.forEach(t => {
      context += `- [WAITING] ${t.time}: ${t.title}\n`;
    });
    
    return context;
  } catch (err) {
    return `Error retrieving Guardian-OS status: ${err.message}`;
  }
}

module.exports = {
  name: "get_pops_status",
  description: "Reads Pops' daily state (Haldol cycle, tasks) to inform context.",
  run
};
