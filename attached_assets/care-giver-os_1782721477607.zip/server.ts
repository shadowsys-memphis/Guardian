import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import fs from 'fs/promises';
import { google } from 'googleapis';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Helper to get Google Workspace OAuth2 client
async function getOAuthClient() {
  const secretsPath = process.env.AI_STUDIO_SECRETS_PATH || '/etc/secrets/firebase-applet-config.json';
  try {
    const fileContents = await fs.readFile(secretsPath, 'utf8');
    const secrets = JSON.parse(fileContents);

    const client = new google.auth.OAuth2(
      secrets.web.client_id,
      secrets.web.client_secret,
      secrets.web.redirect_uris?.[0] || 'https://developers.google.com/oauthplayground'
    );
    
    // Set credentials. In AI Studio, refresh_token is typically available in the same config or passed in headers
    if (secrets.web.refresh_token) {
       client.setCredentials({ refresh_token: secrets.web.refresh_token });
    }
    return client;
  } catch (error) {
    console.error("Error loading OAuth credentials for Workspace:", error);
    return null;
  }
}

// OAuth Client state storage since applet-config handles the underlying client but we might still need to accept the token
// Actually the AI Studio frontend injects the access token into the requests if handled properly. Let's create an endpoint that accepts a token from the frontend if needed, but since we are calling it server-side, it's better.

app.post('/api/calendar/events', async (req, res) => {
  try {
    const { summary, description, startDateTime, endDateTime } = req.body;
    // For simplicity without a DB, we simply require the frontend to pass the access token or we use the injected default one from AI Studio if configured
    // AI Studio places standard OAuth headers if authenticated via preview
    const accessToken = req.headers['x-google-access-token'] || req.headers['authorization']?.replace('Bearer ', '');
    
    if (!accessToken) {
       return res.status(401).json({ error: 'Missing OAuth access token for Google Calendar' });
    }

    const auth = new google.auth.OAuth2();
    auth.setCredentials({ access_token: accessToken as string });

    const calendar = google.calendar({ version: 'v3', auth });
    
    const event = {
      summary: summary || "Medical Appointment",
      description: description || "Caregiver appointment scheduled via Aegis Admin",
      start: {
        dateTime: startDateTime || new Date().toISOString(),
      },
      end: {
         dateTime: endDateTime || new Date(Date.now() + 3600000).toISOString(),
      }
    };

    const response = await calendar.events.insert({
      calendarId: 'primary',
      requestBody: event,
    });

    res.json({ success: true, eventLink: response.data.htmlLink, id: response.data.id });
  } catch (error: any) {
    console.error("Calendar scheduling error:", error);
    res.status(500).json({ error: error.message });
  }
});

let voiceScripts = [
  { id: 'script-1', triggerKey: 'task-m1', tone: 'calm', text: 'Hey Pops, just a reminder to take a sip of your lemon ginger water.', patchNotes: 'Initial script' },
  { id: 'script-2', triggerKey: 'zombie-alert', tone: 'urgent', text: 'Pops, it looks like you are missing a check-in. Please press the button or respond!', patchNotes: 'Added urgency for zombie mode' }
];

let globalHaldolState = {
  dayOfCycle: 3,
  isZombiePhase: true,
  nextInjectionDate: "2026-07-06T00:00:00.000Z"
};

let globalSchedule = [
  { id: "task-1", title: "Morning Hydration (Lemon Ginger)", time: "07:30 AM", status: "Done", quarter: "Q1" },
  { id: "task-2", title: "Breakfast & Meds (Haldol/Anti-hypertensive)", time: "08:30 AM", status: "Done", quarter: "Q1" },
  { id: "task-3", title: "Physical Rotation (Sore prevention)", time: "11:00 AM", status: "Pending", quarter: "Q1" },
  { id: "task-4", title: "Lunch + Cognitive Assessment", time: "01:00 PM", status: "Pending", quarter: "Q2" }
];

app.get('/api/haldol', (req, res) => {
  res.json(globalHaldolState);
});

app.put('/api/haldol', (req, res) => {
  globalHaldolState = { ...globalHaldolState, ...req.body };
  res.json({ success: true, state: globalHaldolState });
});

app.get('/api/schedule', (req, res) => {
  // Returns scheduled tasks for Q1-Q4
  res.json(globalSchedule);
});

app.post('/api/schedule/:id/complete', (req, res) => {
  const { id } = req.params;
  const task = globalSchedule.find(t => t.id === id);
  if (task) {
    task.status = "Done";
    res.json({ success: true, task });
  } else {
    res.status(404).json({ error: "Task not found" });
  }
});

app.post('/api/symptoms', (req, res) => {
  console.log("Logged symptom via API:", req.body);
  res.json({ success: true, message: "Symptom logged to clinical records." });
});

app.get('/api/scripts', (req, res) => {
  res.json(voiceScripts);
});

app.post('/api/scripts', (req, res) => {
  const newScript = { id: Date.now().toString(), ...req.body };
  voiceScripts.push(newScript);
  res.json(newScript);
});

app.put('/api/scripts/:id', (req, res) => {
  voiceScripts = voiceScripts.map(s => s.id === req.params.id ? { ...s, ...req.body } : s);
  res.json({ success: true, scripts: voiceScripts });
});

app.delete('/api/scripts/:id', (req, res) => {
  voiceScripts = voiceScripts.filter(s => s.id !== req.params.id);
  res.json({ success: true, scripts: voiceScripts });
});

app.get('/api/scripts/active', (req, res) => {
  // Used by the backend Jessica phone system!
  res.json({
    activeScripts: voiceScripts,
    timestamp: new Date().toISOString(),
    system: "Care Giver OS -> Jessica Phone Link"
  });
});

app.post('/api/phone/outbound', (req, res) => {
  const { reason, scriptId } = req.body;
  console.log("Triggering outbound SIP/TwiML call to Pops for reason:", reason, scriptId);
  res.json({ success: true, message: `Outbound call triggered successfully for: ${reason}` });
});

// Endpoint to export clinical summary to Google Drive
app.post('/api/drive/export', async (req, res) => {
  try {
    const { content, fileName } = req.body;
    const accessToken = req.headers['x-google-access-token'] || req.headers['authorization']?.replace('Bearer ', '');
    
    if (!accessToken) {
       return res.status(401).json({ error: 'Missing OAuth access token for Google Drive' });
    }

    const auth = new google.auth.OAuth2();
    auth.setCredentials({ access_token: accessToken as string });

    const drive = google.drive({ version: 'v3', auth });

    const fileMetadata = {
      name: fileName || `Clinical_Summary_${new Date().toISOString().slice(0,10)}.txt`,
      mimeType: 'text/plain' // or 'application/vnd.google-apps.document' to create a Google Doc
    };

    const media = {
      mimeType: 'text/plain',
      body: content
    };

    const response = await drive.files.create({
      requestBody: fileMetadata,
      media: media,
      fields: 'id, webViewLink'
    });

    res.json({ success: true, link: response.data.webViewLink, id: response.data.id });
  } catch (error: any) {
    console.error("Google Drive export error:", error);
    res.status(500).json({ error: error.message });
  }
});

// Dedicated clinical summarizer for zero-touch ingestion and compliance auditing
app.post("/api/admin/summary", async (req, res) => {
  try {
    const { currentState } = req.body;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [{
        parts: [{
          text: `You are an expert, medical-grade Care Compliance Evaluator and Clinical Auditor. 
          Compile a professional clinical Efficacy & Compliance Summary based on the following patient care state:
          ${JSON.stringify(currentState, null, 2)}
          
          Construct a high-fidelity formatted report using beautiful clinical structures in Markdown. It must include:
          
          1. **WEEKLY & MONTHLY HEALTH & BIOMETRIC TRENDS**: Analyze biometric readings (e.g., BP 119/74) and track progression.
          2. **MEDICATION & TREATMENT RESPONSES**: Review medication administration records, side effects (such as dry mouth, fatigue, stable responses), and overall adherence.
          3. **ZERO-TOUCH WANT INGESTION METRICS**: Summarize patient requests captured from zero-touch bedsides (e.g., fluid requests, food, adjustments), assessing caregiving team's fluid latency and dispatch performance.
          4. **RESTORATIVE IMPACT ANALYSIS (USEFULNESS VS. UNUSEFULNESS SYSTEM AUDIT)**:
             - **What was ACTUALLY useful**: Explain the practical therapeutic benefits (e.g., zero-touch reduces active shouting and voice strain, keeps direct-care records integrated, and bi-hourly rotation prompts guarantee sore mitigation).
             - **What was UNEFFICIENT / UNUSEFUL / OVERWHELMING**: Provide a objective critical audit of the digital barriers (e.g., excessive hourly visual alerting interrupts sleeping patterns during quiet recovery phases; complex manual logging of repetitive bi-hourly movements takes direct-care time).
          5. **RECOMMENDED WORKFLOW ADJUSTMENTS**: Give 2 specific, practical, actionable clinical tips for refining care (e.g., consolidate sleep-interval checks, or switch alarms to warm silent ambient indicators).
          
          Adopt a highly supportive, professional, and clear tone. Avoid flowery language.`
        }]
      }],
      config: {
        temperature: 0.2
      }
    });

    res.json({ summary: response.text || "Failed to compile care logs." });
  } catch (err: any) {
    console.error("Summary API Error:", err);
    res.status(500).json({ error: err.message || "Internal server error" });
  }
});

// AI Assistant endpoint for zero-touch interaction, calender, appts, and smart notifications
app.post("/api/assistant", async (req, res) => {
  try {
    const { message, history, context, speak } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message is required" });
    }

    const systemInstruction = `
You are Br[AI]n Core, the advanced zero-touch home AI Assistant and logistics coordinator for a high-functioning family caregiving, planning, and smart environment network.
You help households coordinate daily logistics, medical schedules, appointments, smart-home automation statuses, and secure communication channels.

Here is the current Household Context:
${JSON.stringify(context, null, 2)}

Your goals:
1. Process the user's intent to view, add, or alter calendar events, medical schedules, task lists, or smart home settings.
2. If the user asks to add or edit an item (e.g., "Schedule a physical therapy appointment for Mom on Wednesday at 10 AM" or "Turn down living room temperature" or "Set med check reminder for Dad"), respond helpfully and output a structured command in your response inside a block or as part of a JSON-compatible action list so the system can mutate state.
3. Be friendly, clean, direct, and supportive. If requested to "speak", be concise so it sounds good over the phone/speaker.

To execute actions, ALWAYS output a JSON block at the very end of your response (or inline) if you need to mutate the state. Return it in this format:
---ACTION---
[
  {"type": "ADD_EVENT", "payload": {"id": "random-id", "title": "...", "member": "...", "time": "...", "date": "..."}},
  {"type": "TOGGLE_SMART_DEVICE", "payload": {"id": "...", "status": "..."}},
  {"type": "ADD_TASK", "payload": {"title": "...", "category": "..."}}
]
---END_ACTION---
Always keep the regular conversational text clean and easy to read or speak.
`;

    // Initialize content for Gemini call
    const contents = [];
    if (history && history.length > 0) {
      for (const msg of history) {
        contents.push({
          role: msg.role === "assistant" ? "model" : "user",
          parts: [{ text: msg.text }],
        });
      }
    }
    contents.push({
      role: "user",
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || "I am currently processing your request.";

    let audioBase64 = null;
    if (speak) {
      try {
        // Use gemini-3.1-flash-tts-preview for generating voice audio
        const cleanSpeakText = replyText.replace(/---ACTION---[\s\S]*---END_ACTION---/g, "").trim();
        const ttsResponse = await ai.models.generateContent({
          model: "gemini-3.1-flash-tts-preview",
          contents: [{ parts: [{ text: cleanSpeakText }] }],
          config: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: "Zephyr" },
              },
            },
          },
        });
        audioBase64 = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
      } catch (audioErr) {
        console.error("TTS generation failed, proceeding with text-only:", audioErr);
      }
    }

    res.json({
      text: replyText,
      audio: audioBase64,
    });
  } catch (err: any) {
    console.error("Assistant API Error:", err);
    res.status(500).json({ error: err.message || "Internal server error" });
  }
});

// Start express server and integrate Vite
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
